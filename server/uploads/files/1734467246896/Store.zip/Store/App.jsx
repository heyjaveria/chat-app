import { GET_USER_INFO } from ".";
import { useAppStore } from "."
//create these two functions in app.jsx outside the app function
const PrivateRoute = ({children}) => {
    const { userInfo } = useAppStore();
    const isAuthenticated = !userInfo;
    return isAuthenticated ? children : <Navigate to="/auth" />;
}

const AuthRoute = ({children}) => {
    const { userInfo } = useAppStore();
    const isAuthenticated = !userInfo;
    return isAuthenticated ? <Navigate to="/chat" /> : children;
}
<>
    // now in app function in this file 
    //replace auth line with this
    <Route
        path="/auth"
        element={<AuthRoute>
            <Auth />
        </AuthRoute>} />
    // replace chat line with this
    <Route
        path="/chat"
        element={<PrivateRoute>
            <Chat />
        </PrivateRoute>} />
        // replace profile line with this
    <Route
        path="/profile"
        element={<PrivateRoute>
            <Profile />
        </PrivateRoute>} /></>

//now in app function write this on top of everything
const { userInfo, setUserInfo } = useAppStore();

useEffect(() => {
    const getUserData = async () => {
        try{
            const response = await apiClient.get(GET_USER_INFO,{
                withCredentials: true,
            });
            if(response.status === 200 && response.data.id){
                setUserInfo(response.data);
            }else{
                setUserInfo(undefined);
            }
            console.log({ response });
        }catch(error){
            setUserInfo(undefined);
        }finally{
            setLoading(false);
        }
    };
    if(!userInfo){
        getUserData();
    }else{
        setLoading(false);
    }
},[userInfo,setUserInfo]); 
if (loading){
    return <div>Loading...</div>
}
const [loading,setLoading] = setState(true); 

