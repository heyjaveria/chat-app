export const createAuthSlice = (set) => ({
    userInfo: undefined,
    setUserInfo:(userInfo) =>  ({userInfo}),
});